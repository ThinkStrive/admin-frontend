export const adminNavItems = [
  { name: "Dashboard", icon: "fa-border-all", path: "/dashboard" },
    { name: "Users", icon: "fa-users", path: "/users" },
    { name: "Payments", icon: "fa-dollar", path: "/payments" },
  ];