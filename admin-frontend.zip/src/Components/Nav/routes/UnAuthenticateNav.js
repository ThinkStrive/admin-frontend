  export const unAuthenticateNav = [
    { name: "Dashboard", icon: "fa-border-all", path: "/dashboard" },
    { name: "Courses", icon: "fa-chalkboard", path: "/courses" },
    // { name: "Mentors", icon: "fa-user", path: "/mentors" },
    // { name: "Messages", icon: "fa-message", path: "/messages" },
    { name: "Webinar", icon: "fa-play", path: "/webinar" },
    // { name: "Store", icon: "fa-bag-shopping", path: "/store" },
  ];