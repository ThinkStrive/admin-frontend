
  export const userNavItems = [
    { name: "Dashboard", icon: "fa-border-all", path: "/dashboard" },
    { name: "Courses", icon: "fa-chalkboard", path: "/courses" },
    // { name: "Mentors", icon: "fa-user", path: "/mentors" },
    { name: "Webinar", icon: "fa-play", path: "/webinar" },
    // { name: "Messages", icon: "fa-message", path: "/messages" },
    // { name: "Store", icon: "fa-bag-shopping", path: "/store" },
  ];